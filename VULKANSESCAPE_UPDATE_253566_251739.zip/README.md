# Game Progress UPDATE

Eugeni Soler (253566)
David Obrero (251739)

VULKAN’S ESCAPE
At the moment the game is not working, since during this week we are redoing our code, but it's possible to see an example island, the sky cube map and move around the map. 
We have implemented next classes (some of them need to be improved):
    - World (render, update, parse scene, load sky)
    - Stage (stage, stage manager, menu stage, play stage)
    - EntityMesh (render, update, set type, change visibility)
    - EntityPlayer (render, update, hunger, sleep)
    - EntityCollider (check player collisions)
    - EntityUI (render, update, set type)
    - EntityAI (render, update, change state)
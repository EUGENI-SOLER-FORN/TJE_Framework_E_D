# Vulkan's escape
- Entity and EntityMesh are done
- World parsing and rendering is done (scene and skybox).

- Stage (PlayStage and MenuStage) is partially done, with its StageManager. We have to still define if a "outro" or "intro" stage is going to be needed and the conditions for navigating across stages.
- We have partially implemented Player collisions and the camera gameplay that follows it. We also need to manage its stats (healt, points, stamina...).

- We are look forward to adapt and test the start menu, and create an inventory and minimap. For that we still have to download the images to display.
- We also want to add entities that drop items (food and wood) when hit and its health goes to 0, but for that we still have to manage and work out collisions.


Eugeni Soler & David Obrero